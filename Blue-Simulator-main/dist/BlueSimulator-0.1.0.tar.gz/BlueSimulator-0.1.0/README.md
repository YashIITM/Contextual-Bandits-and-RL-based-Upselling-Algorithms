# Blue-Simulator
Simulator for the enviroment generation in various contextual-MAB based applications of algorithms. Works complementary with Blue Bandits
