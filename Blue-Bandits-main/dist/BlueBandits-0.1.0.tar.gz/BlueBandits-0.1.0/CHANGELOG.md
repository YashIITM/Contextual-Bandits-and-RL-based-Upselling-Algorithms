# CHANGELOG

## Version 0.1.0 06/11/2023
1. Launched BlueBandits

